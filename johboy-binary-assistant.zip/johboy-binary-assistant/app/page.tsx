export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white p-4">
      <div className="max-w-md mx-auto">

        <h1 className="text-3xl font-bold text-center mb-6">
          Johboy Binary Assistant
        </h1>

        <div className="bg-zinc-900 rounded-2xl p-4 mb-4 border border-zinc-800">
          <p className="text-zinc-400 mb-2">Market Trend</p>

          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-green-400">
              BUY TREND
            </h2>

            <span className="bg-green-500/20 text-green-400 px-3 py-1 rounded-full">
              ACTIVE
            </span>
          </div>
        </div>

        <div className="bg-zinc-900 rounded-2xl p-4 mb-4 border border-zinc-800">

          <p className="text-zinc-400 mb-2">Signal</p>

          <div className="flex items-center justify-between">

            <div>
              <h2 className="text-4xl font-bold text-green-400">
                CALL
              </h2>

              <p className="text-zinc-500 mt-2">
                Expiry: 3 Minutes
              </p>
            </div>

            <div className="text-right">
              <p className="text-zinc-400">
                Confidence
              </p>

              <h3 className="text-3xl font-bold">
                82%
              </h3>
            </div>

          </div>
        </div>

        <div className="bg-zinc-900 rounded-2xl p-4 border border-zinc-800">

          <p className="text-zinc-400 mb-3">
            Recent Signals
          </p>

          <div className="space-y-2">

            <div className="flex justify-between bg-zinc-800 p-3 rounded-xl">
              <span>CALL</span>
              <span className="text-green-400">WIN</span>
            </div>

            <div className="flex justify-between bg-zinc-800 p-3 rounded-xl">
              <span>PUT</span>
              <span className="text-red-400">LOSS</span>
            </div>

            <div className="flex justify-between bg-zinc-800 p-3 rounded-xl">
              <span>CALL</span>
              <span className="text-green-400">WIN</span>
            </div>

          </div>

        </div>

      </div>
    </main>
  )
}
